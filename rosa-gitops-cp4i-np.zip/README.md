
# Overview

Configuration for OpenShift Container Platform 4 (OCP4) cluster Infrastructure as Code (IaC) automation.

The OCP4 clusters are managed by a GitOps approach (<https://www.redhat.com/en/topics/devops/what-is-gitops>). This repository contains GitOps configuration for the OpenShift clusters.  Kustomize (<https://kustomize.io/>) is used to build the Custom Resource Definition (CRD) files which are applied to each OCP4 cluster.  ArgoCD (<https://argo-cd.readthedocs.io/>) is deployed on each OCP4 cluster and monitors this repository for changes to configuration for its cluster.

The DRY (Don't Repeat Yourself) should be followed for the GitOps configuration to minimise duplicated configuration.  This is not a hard-and-fast rule though and sometimes some minor duplication might make sense if the alternative is a proliferation of files for very little consolidation (e.g. refer to the contents of the overlay directories for the non-production environment (NPE) namespaces).  Note that configuration might also be duplicated temporarily during gradual roll-outs of changes that have been applied to some (but not all) clusters.

# Directory Structure

## Overview tree

```bash
.
├── cluster
│   ├── base
│   └── overlays
│       ├── np
│       ├── poc
│       └── prod
└── namespace
    ├── base
    └── overlays
        ├── np
        ├── poc
        └── prod
```

## Explanation

* Configuration common to all clusters should be put into the "base" directory.
* Configuration unique to a single cluster should be put into the appropriate directory under the "overlays" directory.
* Kustomize in each overlay directory should use configuration in the "base" directory as bases whenever possible to minimise the configuration that needs to be put into each overlay directory.
* ArgoCD on each OCP4 cluster monitors the overlay directory associated to the cluster.
