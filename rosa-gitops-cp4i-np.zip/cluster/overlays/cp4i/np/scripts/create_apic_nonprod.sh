#!/bin/bash

#******************************************************************************
# Usage:
#   ./namespace_create.sh NamespaceName NodeLableName
#******************************************************************************

DIR=`dirname "$0"`

./tls_key_create.sh portal apic certs/apic/api-portal ca_crt tls_crt tls_key apic
./namespace_create.sh apic apic nodeuse/apic=true
./apic_create.sh nonproduction n3xc12.m40 gp3
./portal_create.sh nonproduction n3xc4.m8 gp3 api-padmin-apic.apps.rosa-iop-np.b3hz.p1.openshiftapps.com api-portal.apic.iop-np.rosa.workcover.vic.gov.au
./apic_kustomization_create.sh apic
cp ../template/analytics_offload_secret_tmpl.yaml ../config/apic/analytics_offload_secret.yaml

