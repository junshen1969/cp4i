#!/bin/bash

#******************************************************************************
# Usage:
#   ./namespace_create.sh NamespaceName NodeLableName
#******************************************************************************

DIR=`dirname "$0"`

./cpconsole_create.sh cpconsole cp-console.cp4i.iop-sp.rosa.workcover.vic.gov.au
